package cus1194.medtracker;

/**
 * Created by liu on 3/6/17.
 */

public class Userinformation{

    public String name;
    public String age;
    public String postiion;
    public String NPI;

    public Userinformation(){

    }


        public Userinformation(String name, String age, String postiion, String NPI) {
            this.name = name;
            this.age = age;
            this.postiion = postiion;
            this.NPI = NPI;
        }
}
